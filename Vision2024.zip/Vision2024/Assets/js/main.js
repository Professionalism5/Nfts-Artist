

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
}

window.onscroll = () =>{
    navbar.classList.remove('active');
}

window.addEventListener("scroll",function(){
    var header = this.document.querySelector(".header");
    header.classList.toggle("sticky", window.scrollY > 0);
  } )

//  loaderAnimation
//   function loaderAnimation() {
//     var loader = document.querySelector("#loader")
//     setTimeout(function () {
//         loader.style.top = "-100%"
//     }, 4200)
// }
// loaderAnimation()


// js-for-services

function showContent(title, description, imageUrl) {
  document.getElementById('content-title').innerText = title;
  document.getElementById('content-description').innerText = description;
  document.getElementById('main-image').src = imageUrl;
}


// banner-data

function page4Animation() {
  var elemC = document.querySelector("#elem-container")
  var fixed = document.querySelector("#fixed-image")
  elemC.addEventListener("mouseenter", function () {
      fixed.style.display = "block"
  })
  elemC.addEventListener("mouseleave", function () {
      fixed.style.display = "none"
  })

  var elems = document.querySelectorAll(".elem")
  elems.forEach(function (e) {
      e.addEventListener("mouseenter", function () {
          var image = e.getAttribute("data-image")
          fixed.style.backgroundImage = `url(${image})`
      })
  })
}
page4Animation()



// ###########portfolio-section##################

function loadPortfolioContent() {

  const portfolioItems = [
    {
      image: "Assets/Images/slider2_3.png",
      description: "Vancouver Mountains, Canada",
      title: "The Great Path",
       link: "portfolio.html"
    },
    {
      image: "Assets/Images/slider2_4.png",
      description: "Poon Hill, Nepal",
      title: "Starry Night",
      link: "portfolio.html"
    },
    {
      image: "Assets/Images/portfolio1.jpg",
      description: "Bojcin Forest, Serbia",
      title: "Path Of Peace",
      link: "portfolio.html"
    }
  ];


  const portfolioCards = portfolioItems.map(item => `
    <article class="card__article">
      <img src="${item.image}" alt="image" class="card__img">
      <div class="card__data">
        <span class="card__description">${item.description}</span>
        <h2 class="card__title">${item.title}</h2>
        <a href="${item.link}" class="card__button">Read More</a>
      </div>
    </article>
  `).join('');

  
  document.getElementById('portfolioContainer').innerHTML = `
    <section class="portfolio" id="portfolio">
      <div class="headings">
        <img src="Assets/Images/wave-pattern.webp" alt="">
        <h1 class="heading">Check Out <span>My Latest NFTs Collection</span></h1>
      </div>
      <div class="container">
        <div class="card__container">
          ${portfolioCards}
        </div>
      </div>
    </section>
  `;
}


// ###########services-section##########

function loadServicesContent() {
  // Array data
  const servicesData = [
    {
      image: "Assets/Images/services -1.webp",
      title: "Digital Art",
      description: "We provide stunning digital art that brings your vision to life."
    },
    {
      image: "Assets/Images/b.webp",
      title: "Brand Identity",
      description: "We create distinct brand identities that set you apart"
    },
    {
      image: "Assets/Images/l.webp",
      title: "Illustration Art",
      description: "We deliver captivating illustration art that tells your story."
    },
    {
      image: "Assets/Images/a.webp",
      title: "Animation",
      description: "We create dynamic animation art that brings your ideas to life"
    }
  ];


  const servicesContent = servicesData.map(service => `
    <div class="col-lg-3 col-md-6 col-sm-12">
      <div class="box">
        <img src="${service.image}" alt="">
        <div class="text">
          <h1>${service.title}</h1>
          <p>${service.description}</p>
        </div>
      </div>
    </div>
  `).join('');

  // Insert 
  document.getElementById('servicesContainer').innerHTML = `
    <section class="services" id="services">
      <div class="headings">
        <img src="Assets/Images/wave-pattern.webp" alt="">
        <h1 class="heading">Our <span>Services</span></h1>
      </div>
      <div class="container">
        <div class="row">
          ${servicesContent}
        </div>
      </div>
    </section>
  `;
}



// ##########awards-section############

// function loadAwardSection() {
//   // Array containing award data
//   const awardsData = [
//     {
//       title: "Critics Appreciation Award",
//       date: "Aug 2020, Third Place",
//       image: "Assets/Images/your-image1.webp" // Replace with the correct image path
//     },
//     {
//       title: "Agency Of The Year",
//       date: "Aug 2020, First Place",
//       image: "https://images.unsplash.com/photo-1700975928909-da4a46227a47?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw0fHx8ZW58MHx8fHx8"
//     },
//     {
//       title: "Young Artist’s Award",
//       date: "Dec 2015, First Place",
//       image: "https://images.unsplash.com/photo-1701077137611-9be394bf62f0?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwyMHx8fGVufDB8fHx8fA%3D%3D"
//     },
//     {
//       title: "People’s Choice Award 2021",
//       date: "July 2021, Third Place",
//       image: "https://images.unsplash.com/photo-1701014159309-4a8b84faadfe?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwxOXx8fGVufDB8fHx8fA%3D%3D"
//     },
//     {
//       title: "Awards- Best Artist",
//       date: "May 2019, Second Place",
//       image: "https://images.unsplash.com/photo-1700924546093-f914fd5b8814?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwyOHx8fGVufDB8fHx8fA%3D%3D"
//     },
//     {
//       title: "Best Music NFT 2021",
//       date: "Mar 2021, Second Place",
//       image: "https://images.unsplash.com/photo-1700601437860-e66da79cf6d2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw1OXx8fGVufDB8fHx8fA%3D%3D"
//     }
//   ];

  
//   const awardContent = awardsData.map(award => `
//     <div class="elem" data-image="${award.image}">
//       <div class="overlay"></div>
//       <h2>${award.title}</h2>
//       <p>${award.date}</p>
//     </div>
//   `).join('');

  
//   document.getElementById('awardContainer').innerHTML = `
//     <section class="award" id="award">
//       <div class="headings">
//         <img src="Assets/Images/wave-pattern.webp" alt="">
//         <h1 class="heading">Awards &<span>Achievements</span></h1>
//       </div>
//       <div id="page3">
//         <div id="elem-container">
//           ${awardContent}
//         </div>
//       </div>
//     </section>
//   `;
// }


// #############testimonial-section##############
function loadTestimonialSection() {
  // Arrayal data
  const testimonialsData = [
    {
      image: "Assets/Images/slider2_3.png",
      quote: "We had a great time collaborating with the Filament team. They have my high recommendation!",
      author: "- Marnus Stephen"
    },
    {
      image: "Assets/Images/slider2_8.png",
      quote: "The team drastically improved our product's user experience & increased our business outreach.",
      author: "- Andrew Jettpace"
    },
    {
      image: "Assets/Images/slider2_4.png",
      quote: "I absolutely loved working with the Filament team. Complete experts at what they do!",
      author: "- Stacy Stone"
    }
  ];

  
  const testimonialCards = testimonialsData.map(testimonial => `
    <div class="card">
      <img src="${testimonial.image}" alt="user" />
      <div class="card__content">
        <span><i class="ri-double-quotes-l"></i></span>
        <div class="card__details">
          <p>${testimonial.quote}</p>
          <h4>${testimonial.author}</h4>
        </div>
      </div>
    </div>
  `).join('');

  // Insert 
  document.getElementById('testimonialContainer').innerHTML = `
    <section class="review" id="review">
      <div class="headings">
        <img src="Assets/Images/wave-pattern.webp" alt="">
        <h1 class="heading">Testimonial</h1>
      </div>
      <div class="container">
        <div class="container__left">
          <h1>They Trust Our Work!</h1>
          <p>
            Over 200 companies from diverse sectors consult us to enhance the
            user experience of their products and services.
          </p>
          <p>
            We have helped companies increase their customer base and generate
            multifold revenue with our service.
          </p>
        <a href="Aboutus.html">  <button>Read our success stories</button></a>
        </div>
        <div class="container__right">
          ${testimonialCards}
        </div>
      </div>
    </section>
  `;
}



// ##########team-section##############
function loadTeamSection() {
  // Array 
  const teamMembers = [
    {
      name: "Ayesha",
      role: "Artist",
      image: "Assets/Images/slider2_6.png",
      socialLinks: {
        fb: "#",
        bh: "#",
        in: "#",
        tw: "#"
      }
    },
    {
      name: "Junaid",
      role: "Artist",
      image: "Assets/Images/portfolio4.webp",
      socialLinks: {
        fb: "#",
        bh: "#",
        in: "#",
        tw: "#"
      }
    },
    {
      name: "Rizwan",
      role: "Artist",
      image: "Assets/Images/portfolio5.webp",
      socialLinks: {
        fb: "#",
        bh: "#",
        in: "#",
        tw: "#"
      }
    }
  ];

  const teamContent = teamMembers.map(member => `
    <div class="col-lg-3 col-md-6 col-sm-12 box">
      <img src="${member.image}" alt="${member.name}">
      <h3>${member.name}</h3>
      <h5>${member.role}</h5>
      <div class="icons">
        <a href="${member.socialLinks.fb}" target="_blank">Fb</a>
        <a href="${member.socialLinks.bh}" target="_blank">Bh</a>
        <a href="${member.socialLinks.in}" target="_blank">In</a>
        <a href="${member.socialLinks.tw}" target="_blank">Tw</a>
      </div>
    </div>
  `).join('');


  document.getElementById('teamContainer').innerHTML = `
    <section class="team">
      <div class="headings">
        <img src="Assets/Images/wave-pattern.webp">
        <h1 class="heading">Our <span>Team</span></h1>
      </div>

      <div class="container-fluid">
        <div class="row team-content">
          ${teamContent}
        </div>
      </div>
    </section>
  `;
}


// ###########contact-section#############
function loadContactSection() {
  const contactContent = `
    <section class="contact" id="contact">
      <div class="container">
        <img src="Assets/Images/Image-5.png" alt="">
        <div class="content">
          <h1>Let's Stay In Touch</h1>
          <div class="author">
            <h2>Digital Art, Brand Identity, Illustration Art, CGI Animation</h2>
            <p>
              contact@ealain.com<br>
              (239) 555-0108
            </p>
          </div>
        </div>
      </div>
    </section>
  `;

  document.getElementById('contactContainer').innerHTML = contactContent;
}

// ###########footer-section##########
function loadFooterSection() {
  const footerContent = `
    <section class="footer" id="footer">
      <div id="footer-bottom"></div>
      <nav>
        <div class="logo">
          <img src="Assets/Images/Logo-1.png" alt="">
        </div>
        <div class="navbar">
          <a href="#">Our Work</a>
          <a href="#">Our Testimonial</a>
          <a href="#">Contact us</a>
        </div>
      </nav>
    </section>
  `;

  document.getElementById('footerContainer').innerHTML = footerContent;
}


// ############about-section###########
function loadAboutSection() {
  const aboutContent = `
    <section class="about" id="about">
      <div class="content">
        <h1>
          I Am An
          <img src="Assets/Images/wave-pattern.webp" alt="">
          <span>Artist</span> By
          <img src="Assets/Images/sun.webp" alt="">
          And an adventurer
          <img src="Assets/Images/Astronaut-1.png" alt="">
          By Night. Explore This <span>space</span> with me.
          <img src="Assets/Images/Pyramid.webp" alt="">
        </h1>
      </div>
    </section>
  `;

  document.getElementById('aboutContainer').innerHTML = aboutContent;
}

// full-portfolio
function loadNFTCollection() {
  const nftCollection = [
      {
          imgSrc: "Assets/Images/p4.jpg",
          description: "Vancouver Mountains, Canada",
          title: "The Great Path",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/n1.webp",
          description: "Poon Hill, Nepal",
          title: "Starry Night",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/n.webp",
          description: "Bojcin Forest, Serbia",
          title: "Path Of Peace",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/slider2_9.png",
          description: "Vancouver Mountains, Canada",
          title: "The Great Path",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/slider2_8.png",
          description: "Poon Hill, Nepal",
          title: "Starry Night",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/slider2_7.png",
          description: "Bojcin Forest, Serbia",
          title: "Path Of Peace",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/slider2_3.png",
          description: "Vancouver Mountains, Canada",
          title: "The Great Path",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/slider2_4.png",
          description: "Poon Hill, Nepal",
          title: "Starry Night",
          link: "singleportfolio.html"
      },
      {
          imgSrc: "Assets/Images/portfolio1.jpg",
          description: "Bojcin Forest, Serbia",
          title: "Path Of Peace",
          link: "singleportfolio.html"
      }
  ];

  const nftContainer = document.getElementById('nftContainer');

  const nftCards = nftCollection.map(nft => `
      <article class="card__article">
          <img src="${nft.imgSrc}" alt="${nft.title}" class="card__img">
          <div class="card__data">
              <span class="card__description">${nft.description}</span>
              <h2 class="card__title">${nft.title}</h2>
              <a href="${nft.link}" class="card__button">Read More</a>
          </div>
      </article>
  `).join('');

  nftContainer.innerHTML = nftCards;
}

document.addEventListener('DOMContentLoaded', loadNFTCollection);


// cursor animation 
const cursor = document.querySelector('.cursor');
document.addEventListener('mousemove', e => {
    cursor.setAttribute("style", "top: " + (e.pageY - 10) + "px; left: " + (e.pageX - 10) + "px;")
});
document.addEventListener('click', e => {
    cursor.classList.add("expand");
    setTimeout(() => {
        cursor.classList.remove("expand");
    }, 500);
});


const formOpenBtn = document.querySelector("#form-open"),
  loginpage = document.querySelector(".loginpage"),
  formContainer = document.querySelector(".form_container"),
  formCloseBtn = document.querySelector(".form_close"),
  signupBtn = document.querySelector("#signup"),
  loginBtn = document.querySelector("#login"),
  pwShowHide = document.querySelectorAll(".pw_hide");

formOpenBtn.addEventListener("click", () => loginpage.classList.add("show"));
formCloseBtn.addEventListener("click", () => loginpage.classList.remove("show"));

pwShowHide.forEach((icon) => {
  icon.addEventListener("click", () => {
    let getPwInput = icon.parentElement.querySelector("input");
    if (getPwInput.type === "password") {
      getPwInput.type = "text";
      icon.classList.replace("uil-eye-slash", "uil-eye");
    } else {
      getPwInput.type = "password";
      icon.classList.replace("uil-eye", "uil-eye-slash");
    }
  });
});

signupBtn.addEventListener("click", (e) => {
  e.preventDefault();
  formContainer.classList.add("active");
});
loginBtn.addEventListener("click", (e) => {
  e.preventDefault();
  formContainer.classList.remove("active");
});



let email = document.getElementById("email")
let password = document.getElementById("password")
let cpassword = document.getElementById("cpassword")
let button = document.getElementById("btn1")

window.addEventListener("load", () => {
  if (localStorage.getItem("logedInUser")) {
   
}
})


button.addEventListener("click", () => {
 let localStorageData = localStorage.getItem("users")
if (localStorageData) {
     let eachuser = JSON.parse(localStorageData).find((val) => {
        return val.useremail == email.value
     })


 if (eachuser) {
    if (password.value == eachuser.userpassword){
        localStorage.setItem("logedInUser", JSON.stringify(eachuser))
        window.location.href = "./index.html"
    } else {
        alert("INCORRECT PASSWORD")
    }

 }else{
    alert("INCORRECT EMAIL")
 }
}else {
    alert("GO and sign up first")
    window.location.href = "./signup.html"
}

})



// Function to handle signup form submission
document.getElementById('signupForm').addEventListener('submit', function (event) {
  event.preventDefault(); // Prevent default form submission

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const cpassword = document.getElementById('cpassword').value;

  // Basic validation
  if (password !== cpassword) {
      alert('Passwords do not match');
      return;
  }

  // Simulate successful signup and user data storage
  // Replace this with actual server-side signup logic
  sessionStorage.setItem('userEmail', email);
  sessionStorage.setItem('userName', 'User'); // Change 'User' to the actual user's name if available

  // Redirect to the home page or wherever needed
  window.location.href = 'index.html';
});

// Function to show user data in the navbar
function updateNavbar() {
  const userName = sessionStorage.getItem('userName');
  if (userName) {
      document.getElementById('userIcon').style.display = 'block';
      document.getElementById('userName').textContent = userName;
  }
}

// Call updateNavbar on page load
window.onload = updateNavbar;

// Optional: Toggle password visibility
const pwToggleIcons = document.querySelectorAll('.pw_hide');
pwToggleIcons.forEach(icon => {
  icon.addEventListener('click', function() {
      const pwField = this.previousElementSibling;
      if (pwField.type === 'password') {
          pwField.type = 'text';
          this.classList.replace('uil-eye-slash', 'uil-eye');
      } else {
          pwField.type = 'password';
          this.classList.replace('uil-eye', 'uil-eye-slash');
      }
  });
});



